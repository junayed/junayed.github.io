# Aberdeen — Streets & Landmarks

A browser-based 3D walking game covering Aberdeen city centre, the beachfront and Esplanade, Beach Boulevard, Codona’s, Footdee/Fittie and the harbour mouth. No account, API key or sign-in is required. All runtime libraries and map geometry are bundled.

**Play on desktop or phone:** https://drjunayed.dataxense.co.uk/abdndemo/

**Offline desktop version:** double-click `Aberdeen Real Map.html`, or extract `Aberdeen-Real-Map.zip`. The single HTML contains the JavaScript, geometry, textures and reference photographs. It works without a server or internet connection in a browser with WebGL support.

## Controls

- **Roam:** follow your walker. WASD/arrow keys move, Shift runs, drag turns and scroll changes camera distance.
- **Walk:** first-person movement with building collision boundaries. **Fly:** WASD, Q/E for height, drag to look.
- **Map:** drag to orbit, right-drag to pan, scroll to zoom. Use Places or search for a mapped shop/place. R resets the selected place.
- **Phone:** left joystick moves, drag the scene to turn, Run toggles speed, +/− adjusts follow-camera distance. In Fly the joystick moves level, ↑/↓ rise and descend while held, and Fast changes flight speed. Turning the view works independently of joystick movement; switching movement modes preserves your position. Places opens the searchable drawer. Phone rendering starts with reduced resolution and shadows disabled.
- **City life:** Quiet, Everyday and Busy adjust the street population. People, Traffic and Shops & places switch independently. Busy supports 1,800 animated commuters, 140 additional moving vehicles (including six extra buses), plus the original five moving buses, parked traffic and waiting passengers. Mobile rendering caps nearby animated pedestrians at 160.
- **Weather:** Clear, Rain or Snow, with a separate Day/Night toggle. Snow settles on upward-facing surfaces; night adds a moon, twinkling stars, violet horizon haze, varied warm windows and soft lantern halos.
- **Materials:** procedural granite crystal grain and mortar, bark furrows, leaf textures, gently moving tree crowns, and wet road shading.
- **Lighter graphics:** reduces rendering resolution and disables shadows. Photo guide opens four Earth Studio reference views.

## Included

The selected area is approximately 4.18 × 4.45 km, bounded by longitude −2.124…−2.055 and latitude 57.131…57.171. It is a selected section of Aberdeen, not the whole city.

- 14,063 mapped building polygons and 8,130 road/path segments, with shaped roofs, granite-like façades, windows, cornices and chimneys.
- Dedicated architectural interpretations of Marischal College, Union Square and the Town House, plus Beach Ballroom, Codona’s rides and 157 Footdee cottages/sheds.
- Raised pavements, 17 mapped roundabout islands, 850 shopfronts, 1,088 street lamps, 623 trees and café furniture.
- 380 mapped bus stops, waiting passengers, 188 mapped traffic-signal points and 891 crossing points. Signal-controlled crossings have pedestrian heads; mapped zebra crossings get stripes; unmarked nodes do not receive invented zebra stripes.
- Three bus-gate locations based on the council’s Bridge Street, Guild Street and Market Street corridor. Exact sign placement is illustrative.
- Shaped First/Stagecoach-style buses with destination displays, windows, doors and wheels. Five moving buses and a car follow six mapped street paths, pause at nearby stops and respond to simulated signals. There are also 100 parked/static vehicles.
- Search across 1,487 named mapped businesses and points of interest. Additional named-building and coastal venue markers include 36 mapped coastal businesses. Label pools, collision avoidance and mobile limits keep the scene readable.

## Accuracy and scope

This is a stylized architectural game interpretation, **not an identical digital twin or Google’s 3D city mesh**. Street connections and building outlines come from OpenStreetMap. Height tags are used when present; otherwise tagged storeys or type-based estimates supply heights. Many roofs, windows, façades, ornaments, shopfronts, lights, shelters and people are procedural approximations. Terrain is flat, and interiors and accurate bridge/road elevations are not reconstructed. Buildings and pedestrian clothing are illustrative; people are not representations of actual individuals.

Traffic timing, bus routes, route numbers, liveries, departures and waiting passengers are game simulations, not live transport information or a travel planner. The map snapshot may differ from current construction or restrictions, including the evolving Beach Boulevard area. The app is not for real-world road navigation.

The optional photographic surface projects nine overhead Earth Studio images onto a flat reference plane and roof surfaces. Seams, displaced roofs and alignment differences can occur. Four reference photographs are provided separately in Photo guide. Earth Studio exports camera/tracking information, not playable building geometry. The original 492 frames, camera exports and supplied reference video remain in the local workspace; they are not included in the web repository.

## Source and build

The published repository contains editable `src/`, locally bundled Three.js in `vendor/`, and the ready-to-serve website in `docs/`. Generated geometry is included; there are no runtime mapping-service requests.

```sh
npm ci
npm run build
npm run preview
```

Open the preview URL printed by Python. The game source repository keeps its distributable in `docs/`. The portfolio repository publishes a copy only under `abdndemo/`; its homepage and domain configuration are unchanged. The separate game repository’s Pages deployment is disabled. Changes to HTML/CSS can be made directly in `docs/`; JavaScript changes are bundled with esbuild. The local workspace equivalent uses `dist/` instead of `docs/`.

`scripts/package-single.py` generates the offline HTML and ZIP from `docs/`. In the original workspace use `src/package_single.py` from `dist/`. Python geometry-preparation scripts are preserved for provenance but expect the separate workspace’s source GeoJSON/camera captures and Python packages (Shapely, NumPy, SciPy and Pillow); normal builds do not need them.

The web version caches its core files after the first successful visit where service workers are supported. Download the single HTML for a dependable standalone offline copy. Performance depends on the device’s WebGL support; responsive layout and joystick behavior were checked at a 390 px viewport, not on physical phone hardware.

## Sources and attribution

- Map data **© OpenStreetMap contributors**, [ODbL](https://www.openstreetmap.org/copyright). Generated `*-data.js` geometry is derived map data under ODbL. The extraction bounds and Overpass query are in `data/`; individual mapped objects retain their OSM IDs. Snapshot prepared 27 October 2026.
- Imagery: **Google Earth**. Data SIO, NOAA, U.S. Navy, NGA, GEBCO, Landsat / Copernicus, Airbus. Source frames retain attribution. The projected image and four references remain third-party imagery and are not relicensed as original code or OSM data.
- [Earth Studio camera export documentation](https://earth.google.com/studio/docs/advanced-features/3d-camera-export/).
- [Marischal College, Historic Environment Scotland LB20096](https://portal.historicenvironment.scot/designation/LB20096), [architectural reference](https://www.holmesmiller.com/project/marischal-college).
- [Beach Ballroom, HES LB20314](https://portal.historicenvironment.scot/designation/LB20314), [Codona’s](https://www.codonas.com/info).
- [Aberdeen City Council bus gates](https://www.aberdeencity.gov.uk/Council-Services/roads-parking-and-travel/bus-lanes-and-bus-gates/information/bus-gates-frequently-asked-questions), [First Aberdeen network maps](https://www.firstbus.co.uk/aberdeen/routes-and-maps/network-maps), [beachfront project](https://generationaberdeen.co.uk/beachfront/).
- Three.js is bundled under MIT; see `THREE-LICENSE.txt`. Bus operator names are descriptive references; there is no operator affiliation or endorsement.

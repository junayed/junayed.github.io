# Aberdeen — Streets & Landmarks

A browser-based 3D walking game covering Aberdeen city centre, the beachfront and Esplanade, Beach Boulevard, Codona’s, Footdee/Fittie and the harbour mouth. No account, API key or sign-in is required. All runtime libraries and map geometry are bundled.

**Play on desktop or phone:** https://drjunayed.dataxense.co.uk/abdndemo/

**Offline desktop version:** double-click `Aberdeen Real Map.html`, or extract `Aberdeen-Real-Map.zip`. The single HTML contains the JavaScript, geometry, textures and reference photographs. It works without a server or internet connection in a browser with WebGL support.

## Controls

- **Roam:** follow your walker. WASD/arrow keys move, Shift runs, drag turns and scroll changes camera distance.
- **Walk:** first-person movement with building collision boundaries. **Fly:** WASD, Q/E for height, drag to look.
- **Map:** drag to orbit, right-drag to pan, scroll to zoom. Use Places or search for a mapped shop/place. R resets the selected place.
- **Phone:** left joystick moves, drag the scene to turn, Run toggles speed, +/− adjusts follow-camera distance. In Fly the joystick moves level, ↑/↓ rise and descend while held, and Fast changes flight speed. Turning the view works independently of joystick movement; switching movement modes preserves your position. Places opens the searchable drawer. Phone rendering starts with reduced resolution and shadows disabled.
- **City life:** Quiet, Everyday and Busy adjust the street population. People, Traffic and Shop signs switch independently. Busy supports 1,800 animated commuters, 140 additional moving vehicles (including six extra buses), plus the original five moving buses, parked traffic and waiting passengers. Mobile rendering caps nearby animated pedestrians at 160.
- **Weather:** Clear, Sunny day, Rain or Snow, with a separate Day/Night toggle. Snow settles on upward-facing surfaces; night adds a moon, twinkling stars, violet horizon haze, varied warm windows and soft lantern halos.
- **Materials:** procedural granite crystal grain and mortar, bark furrows, leaf textures, gently moving tree crowns, and wet road shading.
- **Lighter graphics:** reduces rendering resolution and disables shadows. Photo guide opens four Earth Studio reference views.

## Included

The selected area is approximately 4.18 × 4.45 km, bounded by longitude −2.124…−2.055 and latitude 57.131…57.171. It is a selected section of Aberdeen, not the whole city.

- 14,063 mapped building polygons and 8,130 road/path segments, with shaped roofs, granite-like façades, windows, cornices and chimneys.
- Dedicated architectural interpretations of Bon Accord Centre, Marischal College, Union Square and the Town House, plus Beach Ballroom, Codona’s rides and 157 Footdee cottages/sheds.
- Raised pavements, 17 mapped roundabout islands, 850 shopfronts, 1,088 street lamps, 623 trees and café furniture.
- 380 mapped bus stops, waiting passengers, 188 mapped traffic-signal points and 891 crossing points. Signal-controlled crossings have pedestrian heads; mapped zebra crossings get stripes; unmarked nodes do not receive invented zebra stripes.
- Three bus-gate locations based on the council’s Bridge Street, Guild Street and Market Street corridor. Exact sign placement is illustrative.
- Shaped First/Stagecoach-style buses with destination displays, windows, doors and wheels. Five moving buses and a car follow six mapped street paths, pause at nearby stops and respond to simulated signals. There are also 100 parked/static vehicles.
- Search across 1,487 named mapped businesses and points of interest. 1,443 physical façade sign placements include 57 coastal businesses and venues. Names are mounted on fixed building walls with bordered fascia panels, brand-inspired colours, café awnings and warm night lighting; there are no floating shop pins or billboard cards. Nearby physical sign textures are reused to keep mobile memory bounded.

## Accuracy and scope

This is a stylized architectural game interpretation, **not an identical digital twin or Google’s 3D city mesh**. Street connections and building outlines come from OpenStreetMap. Height tags are used when present; otherwise tagged storeys or type-based estimates supply heights. Many roofs, windows, façades, ornaments, shopfronts, lights, shelters and people are procedural approximations. Terrain is flat, and interiors and accurate bridge/road elevations are not reconstructed. Buildings and pedestrian clothing are illustrative; people are not representations of actual individuals.

Traffic timing, bus routes, route numbers, liveries, departures and waiting passengers are game simulations, not live transport information or a travel planner. The map snapshot may differ from current construction or restrictions, including the evolving Beach Boulevard area. The app is not for real-world road navigation.

The optional photographic surface projects nine overhead Earth Studio images onto a flat reference plane and roof surfaces. Seams, displaced roofs and alignment differences can occur. Four reference photographs are provided separately in Photo guide. Earth Studio exports camera/tracking information, not playable building geometry. The original 492 frames, camera exports and supplied reference video remain in the local workspace; they are not included in the web repository.

## Source and build

The published repository contains editable `src/`, locally bundled Three.js in `vendor/`, and the ready-to-serve website in `docs/`. Generated geometry is included; there are no runtime mapping-service requests.

```sh
npm ci
npm run build
npm run preview
```

Open the preview URL printed by Python. The game source repository keeps its distributable in `docs/`. The portfolio repository publishes a copy only under `abdndemo/`; its homepage and domain configuration are unchanged. The separate game repository’s Pages deployment is disabled. Changes to HTML/CSS can be made directly in `docs/`; JavaScript changes are bundled with esbuild. The local workspace equivalent uses `dist/` instead of `docs/`.

`scripts/package-single.py` generates the offline HTML and ZIP from `docs/`. In the original workspace use `src/package_single.py` from `dist/`. Python geometry-preparation scripts are preserved for provenance but expect the separate workspace’s source GeoJSON/camera captures and Python packages (Shapely, NumPy, SciPy and Pillow); normal builds do not need them.

The web version caches its core files after the first successful visit where service workers are supported. Download the single HTML for a dependable standalone offline copy. Performance depends on the device’s WebGL support; responsive layout and joystick behavior were checked at a 390 px viewport, not on physical phone hardware.

## Sources and attribution

- Map data **© OpenStreetMap contributors**, [ODbL](https://www.openstreetmap.org/copyright). Generated `*-data.js` geometry is derived map data under ODbL. The extraction bounds and Overpass query are in `data/`; individual mapped objects retain their OSM IDs. Snapshot prepared 27 October 2026.
- Imagery: **Google Earth**. Data SIO, NOAA, U.S. Navy, NGA, GEBCO, Landsat / Copernicus, Airbus. Source frames retain attribution. The projected image and four references remain third-party imagery and are not relicensed as original code or OSM data.
- [Earth Studio camera export documentation](https://earth.google.com/studio/docs/advanced-features/3d-camera-export/).
- [Marischal College, Historic Environment Scotland LB20096](https://portal.historicenvironment.scot/designation/LB20096), [architectural reference](https://www.holmesmiller.com/project/marischal-college).
- [Beach Ballroom, HES LB20314](https://portal.historicenvironment.scot/designation/LB20314), [Codona’s](https://www.codonas.com/info).
- [Aberdeen City Council bus gates](https://www.aberdeencity.gov.uk/Council-Services/roads-parking-and-travel/bus-lanes-and-bus-gates/information/bus-gates-frequently-asked-questions), [First Aberdeen network maps](https://www.firstbus.co.uk/aberdeen/routes-and-maps/network-maps), [beachfront project](https://generationaberdeen.co.uk/beachfront/).
- Three.js is bundled under MIT; see `THREE-LICENSE.txt`. Bus operator names are descriptive references; there is no operator affiliation or endorsement.

## Street character update

Original wall-mural artwork is mounted on 13 mapped building walls near the Green, Blackfriars, George Street, Berry Street and the coast. These are new game artworks rather than copies of existing Nuart murals. See [mural asset and generation prompt](MURAL-ASSET.md). 743 mapped ground parking areas have 7,620 marked bays and 4,638 parked cars across 640 lots; each area with a valid bay contains a car. The remaining 103 narrow/obstructed areas retain their mapped surface without cars forced into buildings or roads. underground and multistorey parking is not flattened into surface lots. Beachfront food carts, campers, café furniture and seated/chatting groups add social activity. Retail signs and Bon Accord entrances are fixed architectural geometry.

## Festive city and seaside life

- Night reveals a Broad Street Christmas village with timber chalets, an ice rink and skaters, a rotating miniature carousel, Christmas trees, candy canes, warm stall signs and a market crowd. Christmas destinations switch the scene to night automatically. December-style stars and illuminated garlands span the shopping streets, and Codona’s gains colourful twinkling lights.
- Sunny day adds stronger overhead sunshine, white cloud banks and circling, flapping gulls. The North Sea and harbour have animated procedural ripples, foam, sun glints and moonlight. Eleven new docked vessel models and one gently moving offshore vessel supplement the original harbour boats.
- More ice-cream carts, fixed café plaques, picnic tables and promenade benches populate the beachfront.
- Coral shared cycles and electric scooters, delivery riders with food bags, masked/helmeted riders, family walkers, neutral dark-clothed friend groups and marked police patrols add street character. Shared-cycle hubs are illustrative game placements, not actual Voi service infrastructure. Routes avoid the closed eastern Beach Boulevard and private-vehicle bus-priority restrictions.
- Union Terrace Gardens and Bon Accord Terrace Gardens use cached mapped boundaries with garden paths, steps, flowerbeds, benches and garden structures. Union Terrace includes glazed pavilions, statues and a Halo interpretation. Garden levels remain decorative on the game’s flat terrain. Tivoli has a dedicated façade treatment, physical marquee and queue, with social groups at mapped popular pubs.
- Walk or Roam near visitors to see greeting/farewell captions. Street voices optionally uses an installed local British-English speech voice; captions work without speech support or a network. People and Traffic switches also control the added riders, families and police.

Design references: [Aberdeen Inspired Christmas market](https://www.aberdeeninspired.com/festival/aberdeen-christmas-market/curated-in-the-square-stallholder-information), [official historic village map](https://www.aberdeeninspired.com/files/Village-map-2023.pdf), [Tivoli Theatre](https://www.thetivolitheatre.com/getting-here), [Port of Aberdeen quays](https://www.portofaberdeen.co.uk/port-information/quayside). These details are game interpretations, not a surveyed reconstruction, current event schedule, live traffic or live port movements.

## Residential greenery

Front-garden planting follows the user's two residential reference photos: leafy broadleaf trees with visible branching and alpha-cutout leaf clusters, clipped evergreen hedges, pink hydrangea-like shrubs, small grass tufts, low granite boundaries with open access paths, and timber planters with staked young trees. A designed planting layer fits 420 eligible mapped home frontages, avoiding mapped vehicle roads, surface car parks and building footprints. The planting is a game interpretation rather than a survey of individual private gardens. Existing street trees use the same leafier rendering; nearby trees receive more branching and leaf detail, while small flowers/grass details fade at distance for mobile. Search Places for “Leafy homes” to view an example. All foliage textures are generated locally in canvas and embedded by the normal offline build.

## Everyday city life

Small animated street scenes add buskers with guitars and listeners, dog walkers with leads, promenade joggers, shoppers carrying bags, parents with prams, photographers, café staff with trays, couriers with parcels and street cleaners. A physical papers-and-flowers stand complements the café and shopfront activity. People occasionally pause, turn and wave; some carry umbrellas in rain. Walk near them for greeting captions. These are illustrative everyday game activities, not current events or real individuals.

Cached mapped post boxes have red pillar models with letter slots, collection plates and crown details. Mapped telephone points receive red, glazed K6-inspired kiosks with physical TELEPHONE panels and warm night lights. Most source telephone points are modern KX100 units; the red kiosk treatment is a deliberate visual interpretation rather than a claim about each existing booth. Fixtures are checked against roads and buildings, with short safe placement adjustments where the source point is obstructed.

Eight mapped above-ground car parks gain open decks, parapets, supporting columns, ramps, entrance signs, marked roof bays and parked cars. Union Square parking is elevated above its retail base because its mapped footprint overlaps the shops below. Estimated decks and ramps are architectural game interpretations. Existing mapped ground lots remain in place. Search Places for “open decks”, “Red telephone”, “Royal Mail”, “Street life” or “Dog walkers”. People and Traffic switches and Quiet/Everyday/Busy density also control the additions. People, detailed cars and nearby street props use distance limits for mobile.
